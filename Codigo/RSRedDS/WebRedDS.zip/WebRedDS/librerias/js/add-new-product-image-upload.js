$(function() {
	"use strict";
	
	
	   $(document).ready(function () {
			$('#image-uploadify').imageuploadify();
		})
	
	
	});